declare module "@salesforce/apex/CandidateGradeController.getCandidateGrade" {
  export default function getCandidateGrade(param: {contactId: any}): Promise<any>;
}
